

from __future__ import print_function
import sys
import numpy as np
import random
from itertools import islice
from collections import namedtuple, defaultdict


#
# Model
#


Problem = namedtuple("Problem", [
    "R", "C", "A", "L", "V", "B", "T", "Rs", "Cs",
    "targets",
    "layers",
    "cov"
])


class Loon(object):
    def __init__(self, row, col):
        self.row = row
        self.col = col
        self.layer = -1
        self.history = []
        self.out = False


def simulate(p, result):
    loons = [Loon(p.Rs, p.Cs) for _ in range(p.B)]
    total_score = 0
    # For each simulation step
    for step, moves in enumerate(result):
        print("Step", step)
        # Move each balloon
        covered = set()
        for move, loon in zip(moves, loons):
            loon.layer += move
            if loon.layer >= 0:
                new_row, new_col = p.layers[loon.layer, loon.row, loon.col]
                loon.row = new_row
                loon.col = new_col
                covered.update(p.cov[loon.row, loon.col])
        total_score += len(covered)
    return total_score


#
# Solve
#


def columnsdist(c1, c2, C):
    return min(abs(c1 - c2), C - abs(c1 - c2))


def iscovered(target, row, col, C, V):
    u, v = target
    return (row - u) ** 2 + columnsdist(col, v, C) ** 2 <= V * V


def compute_cov(R, C, targets, loon_radius):
    rewards = defaultdict(list) #np.zeros((R, C, len(targets)), dtype=np.bool_)
    for i, (target_row, target_col) in enumerate(targets):
        for row in range(-loon_radius, loon_radius + 1):
            for col in range(-loon_radius, loon_radius + 1):
                if ((row + target_row) < R) and ((row + target_row) >= 0):
                    if iscovered((target_row, target_col), row, col, C, loon_radius):
                        rewards[target_row + row, (target_col + col) % C].append(i)
    return rewards


def compute_covered_targets(R, C, targets):
    covered = np.zeros((R, C, len(targets)), dtype=np.bool_)


def decision(problem, model, loon):
    if loon.out:
        return 0
    if loon.layer == -1:
        return random.randint(0, 1)
    move = np.random.choice((-1, 0, 1)) #, p=model[loon.layer, loon.row, loon.col])
    if move == -1 and loon.layer > 0:
        return move
    elif move == 1 and loon.layer < (problem.A - 1):
        return move
    else:
        return 0


def solve(p):
    result = []
    # For each position in 3D world, and for each action
    # associate a transition probability
    model = np.zeros((p.A, p.R, p.C, 3), dtype=np.float32) + (1.0 / 3.0)
    loons = [Loon(p.Rs, p.Cs) for _ in range(p.B)]

    # Run simulation
    print("Start simulation")
    for step in range(p.T):
        print("Step", step)
        moves = []
        for loon in loons:
            # Decide move
            move = decision(p, model, loon)
            # Update loon position
            loon.layer += move
            new_row, new_col = p.layers[loon.layer, loon.row, loon.col]
            loon.row = new_row
            loon.col = new_col
            # Update
            moves.append(move)
        result.append(moves)
    return result


#
# IO
#


def read_input(path):
    with open(path, "rb") as input_file:
        content = iter(map(int, input_file.read().split()))
        R, C, A, L, V, B, T, Rs, Cs = islice(content, 9)
        targets = [tuple(islice(content, 2)) for _ in range(L)]
        layers = np.zeros((A, R, C, 2), dtype=np.int8)
        for layer in range(A):
            for row in range(R):
                for col in range(C):
                    layers[layer, row, col] = tuple(islice(content, 2))
        cov = compute_cov(R, C, targets, V)
        return Problem(R, C, A, L, V, B, T, Rs, Cs, targets, layers, cov)


def dump_solution(result, output_filename="output.sol", prefix=""):
    output_path = "%s_%s" % (prefix, output_filename)
    with open(output_path, 'wb') as output:
        for moves in result:
            print(' '.join(map(str, moves)), file=output)


def main():
    print("Read input")
    problem = read_input(sys.argv[1])
    print("Solve problem")
    result = solve(problem)
    print("Simulate solution")
    score = simulate(problem, result)
    print(score)
    print("Dump solution")
    dump_solution(result, prefix=str(score))


if __name__ == "__main__":
    main()
