#!/usr/bin/env python
# -*- coding: utf-8 -*-


import hashcode.main as main


def test_test():
    assert main.main() is None
