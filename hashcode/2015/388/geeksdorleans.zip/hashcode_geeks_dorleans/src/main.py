#! /usr/bin/env python
# -*- coding: utf-8 -*-


"""
Solve Google HashCode 2015.

Usage:
    solve [options] <in> <out>
    solve -h | --help

Options:
    -h, --help      Show help.
"""

from __future__ import unicode_literals, print_function
from collections import namedtuple, defaultdict
from pprint import pprint
from itertools import islice
import docopt
import random
import numpy as np


class Row(object):
    def __init__(self, row_index, size, unavailables):
        self.row_index = row_index
        if len(unavailables) == 0:
            self.blocks = [(0, size)]
        else:
            unavailables = sorted(unavailables)
            self.size = size
            self.blocks = []

            last = 0
            for u in unavailables:
                if (u - last) > 0:
                    self.blocks.append((last, u - last))
                last = u + 1
            if last < size:
                self.blocks.append((last, size - unavailables[-1] - 1))
            self.blocks.sort(reverse=True, key=lambda b: b[1])

    def fit(self, size):
        for b in self.blocks:
            if b[1] == size:
                return True
        return False

    def __contains__(self, size):
        return len(filter(lambda b: size <= b, [b[1] for b in self.blocks]))

    def freeslots(self):
        return sum([b[1] for b in self.blocks])

    def getmax(self):
        return self.blocks[0][1]

    def getmin(self):
        return self.blocks[-1][1]

    def useslot(self, size, blocksize=-1):
        pos, blocksize = self.blocks[0]
        assert blocksize >= size
        for s in self.blocks:
            if s[1] < size:
                break
            else:
                pos, blocksize = s

        index = self.blocks.index((pos, blocksize))
        self.blocks.pop(index)
        if size < blocksize:
            self.blocks.append((pos + size, blocksize - size))
            self.blocks.sort(reverse=True, key=lambda b: b[1])
        elif size > blocksize:
            assert False
        return pos


Server = namedtuple('Server', [
    'line',
    'pos',
    'group'
])


Data = namedtuple('Data', [
    'rows',
    'slots',
    'unavailables',
    'pools',
    'servers'
])


def read_data(path):
    data = None
    with open(path, 'rb') as input_file:
        data = iter(input_file.read().split('\n'))
    R, S, U, P, M = map(int, next(data).split())
    print(R, "rows")
    print(S, "slots")
    print(U, "unavailable")
    print(P, "pools")
    print(M, "servers")

    indispo = []
    for line in islice(data, U):
        indispo.append(map(int, line.split()))

    servers = []
    for i, line in enumerate(islice(data, M)):
        size, capacity = map(int, line.split())
        servers.append((i, capacity, size))

    return Data(
        rows=R,
        slots=S,
        pools=P,
        unavailables=indispo,
        servers=servers
    )


def format_solution(path, servers, prefix):
    with open(prefix + path, 'wb') as output:
        for server_solution in servers:
            if server_solution:
                print(" ".join(map(str, server_solution)), file=output)
            else:
                print("x", file=output)


def solve(data):
    # Sort servers by capacity / size
    servers = sorted(
        data.servers,
        reverse=True,
        key=lambda (_, capacity, size): float(capacity) / float(size) #float(capacity) / float(size)
    )

    # Build a list of rows
    unavailables = defaultdict(list)
    for (line, slot) in data.unavailables:
        unavailables[line].append(slot)
    rows = [Row(i, data.slots, unavailables[i]) for i in range(data.rows)]
    rows.sort(reverse=True, key=lambda r: r.getmax())

    # Assign servers to lines
    result = {}
    capacity_row_group = np.zeros((data.rows, data.pools))
    group_scores_cumul = np.zeros((data.pools,))

    for (server_id, capacity, size) in servers:
        # Select best overal group
        groups_scores = np.zeros((data.rows, data.pools))
        for j in range(data.rows):
            groups_scores[j, :] = group_scores_cumul - capacity_row_group[j, :]
        min_group_score = groups_scores.min(axis=0)
        best_group_id = min_group_score.argmin()

        # Rows with enough space to fit the server
        possible_rows = [
            (row, capacity_row_group[row.row_index, best_group_id]) for row in rows
            if size in row
        ]

        if len(possible_rows) == 0:
            result[server_id] = None
            continue

        # Get the best row
        possible_rows.sort(key=lambda (_, score): score)
        best_row, _ = random.choice(possible_rows[0:min(len(possible_rows), 10)])

        # Fit server in best row
        server_pos = best_row.useslot(size)

        # Update capacity of each group, on best row
        capacity_row_group[best_row.row_index, best_group_id] += capacity
        group_scores_cumul[best_group_id] += capacity

        # Update result
        result[server_id] = (best_row.row_index, server_pos, best_group_id)

        # print("> sid: %s, rid: %s, gid: %s, cap: %s, size: %s" % (server_id, best_row.row_index, group_id, capacity, size))
        # print(server_id, best_row.row_index, group_id, capacity, size)

    # Compute score
    group_scores = [0 for _ in range(data.pools)]
    for i in range(data.pools):
        total = 0
        for j in range(data.rows):
            total += capacity_row_group[j][i]
        group_scores[i] = total

    # Compute ottal score
    group_scores_min = group_scores[0]
    for i in range(data.pools):
        score = group_scores[i]
        for j in range(data.rows):
            score = min(score, group_scores[i] - capacity_row_group[j][i])
        group_scores_min = min(group_scores_min, score)

    return group_scores_min, [result[i] for i in range(len(servers))]


def main():
    args = docopt.docopt(__doc__)
    data = read_data(args['<in>'])

    maxi, result = solve(data)
    format_solution(args['<out>'], result, prefix=str(maxi))
    for _ in range(1000):
        score, result = solve(data)
        print(score)
        if score > maxi:
            print("BETTER")
            maxi = score
            format_solution(args['<out>'], result, prefix=str(score))



if __name__ == "__main__":
    # # --###----#
    # l = Row(0, 10, [2, 3, 4, 9])
    # pprint(l.blocks)
    # # [2, 4]
    # print(l.freeslots())
    # print(l.getmax())
    # print(l.getmin())
    # l.useslot(3)
    # pprint(l.blocks)
    main()
